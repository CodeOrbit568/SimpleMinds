package quizproject;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AdminSignUp extends JFrame implements ActionListener {

    JTextField user, pass, user_n;
    JButton sign, al,backImageButton;

    AdminSignUp() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        // Adding GIF with border
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/giphy.gif"));
        JLabel image = new JLabel(i1);
        image.setBounds(60, 100, 600, 500);
        image.setBorder(BorderFactory.createLineBorder(Color.BLACK, 5));  // Black border around GIF
        add(image);
        
        JLabel heading = new JLabel("Simple Minds");
        heading.setBounds(555, 20, 300, 45);
        heading.setFont(new Font("Viner Hand ITC", Font.BOLD, 40));
        heading.setForeground(new Color(30, 144, 254));
        add(heading);

        // Main content panel with titled border for the form
        JPanel contentPanel = new JPanel();
        contentPanel.setBounds(730, 90, 550, 510);
        contentPanel.setLayout(null);
        contentPanel.setBackground(Color.WHITE);
        contentPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(30, 144, 254), 5),
                "Admin Sign Up ", TitledBorder.CENTER, TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 18), new Color(30, 144, 254)
        ));
        add(contentPanel);

        // Heading Label
        

        // Name Field and Label
        JLabel name = new JLabel("Enter Name");
        name.setBounds(50, 70, 300, 18);
        name.setFont(new Font("Mangolian Baiti", Font.BOLD, 20));
        name.setForeground(new Color(30, 144, 254));
        contentPanel.add(name);

        user_n = new JTextField();
        user_n.setBounds(50, 95, 400, 30);
        user_n.setFont(new Font("Times New Roman", Font.BOLD, 20));
        user_n.setBorder(BorderFactory.createLineBorder(new Color(30, 144, 254)));
        contentPanel.add(user_n);

        // Username Field and Label
        JLabel username = new JLabel("Enter Username");
        username.setBounds(50, 140, 300, 18);
        username.setFont(new Font("Mangolian Baiti", Font.BOLD, 20));
        username.setForeground(new Color(30, 144, 254));
        contentPanel.add(username);

        user = new JTextField();
        user.setBounds(50, 165, 400, 30);
        user.setFont(new Font("Times New Roman", Font.BOLD, 20));
        user.setBorder(BorderFactory.createLineBorder(new Color(30, 144, 254)));
        contentPanel.add(user);

        // Password Field and Label
        JLabel password = new JLabel("Enter Password");
        password.setBounds(50, 210, 300, 18);
        password.setFont(new Font("Mangolian Baiti", Font.BOLD, 20));
        password.setForeground(new Color(30, 144, 254));
        contentPanel.add(password);

        pass = new JTextField();
        pass.setBounds(50, 235, 400, 30);
        pass.setFont(new Font("Times New Roman", Font.BOLD, 20));
        pass.setBorder(BorderFactory.createLineBorder(new Color(30, 144, 254)));
        contentPanel.add(pass);

        // Sign-Up Button
        sign = new JButton("Sign Up");
        sign.setBounds(165, 290, 160, 35);
        sign.setBackground(new Color(30, 144, 254));
        sign.setForeground(Color.WHITE);
        sign.setFont(new Font("Arial", Font.BOLD, 16));
        sign.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        sign.addActionListener(this);
        contentPanel.add(sign);

        // Already Have Account Label
        JLabel haveA = new JLabel("Already have an account?");
        haveA.setBounds(164, 335, 180, 18);
        haveA.setFont(new Font("Mangolian Baiti", Font.BOLD, 13));
        haveA.setForeground(new Color(30, 144, 254));
        contentPanel.add(haveA);

        // Login Button
        al = new JButton("Login");
        al.setBounds(175, 360, 140, 35);
        al.setBackground(new Color(30, 144, 254));
        al.setForeground(Color.WHITE);
        al.setFont(new Font("Arial", Font.BOLD, 14));
        al.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        al.addActionListener(this);
        contentPanel.add(al);
        
        ImageIcon originalIcon = new ImageIcon(ClassLoader.getSystemResource("icon/back.png"));

// Scale the image to fit the button dimensions
Image scaledImage = originalIcon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
ImageIcon backIcon = new ImageIcon(scaledImage);

backImageButton = new JButton(backIcon);
backImageButton.setBounds(10, 10, 40, 40);  // Adjusted for top-right corner
backImageButton.setBackground(Color.WHITE);
backImageButton.setBorder(null);  // Remove border for icon button appearance
backImageButton.addActionListener(this);
add(backImageButton);


        setSize(1350, 740);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == al) {
            setVisible(false);
            new AdminLogin();
        } else if (e.getSource() == sign) {
            
                if(user_n==null||user==null||pass==null)
                {
                     JOptionPane.showMessageDialog(this, "please insert the data");
                     new AdminSignUp().setVisible(true);

                }
                else{
            try {
                Class.forName("oracle.jdbc.driver.OracleDriver");
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "root");
                PreparedStatement ps = con.prepareStatement("INSERT INTO admin (USERNAME, PASSWORD, NAME) VALUES (?, ?, ?)");

                String n = user_n.getText();
                String u = user.getText();
                String p = pass.getText();

                ps.setString(1, u);
                ps.setString(2, p);
                ps.setString(3, n);
                ps.executeUpdate();

                JOptionPane.showMessageDialog(this, "Record inserted successfully.");

                con.close();

                setVisible(false);
                new Admin();
            } catch (Exception ex) {
                ex.printStackTrace();
            }}
        }
        else if(e.getSource()==backImageButton)
        {
            setVisible(false);
            new Start();
            
        }
    }

    public static void main(String args[]) {
        new AdminSignUp();
    }
}
