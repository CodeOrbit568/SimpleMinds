package quizproject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Text extends JFrame {

    private String languageTable;

    public Text(String languageTable) {
        this.languageTable = languageTable;
        
        setTitle("Form with Six Text Boxes");
        setSize(800, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(8, 1, 10, 10));

        JTextField textField1 = new JTextField(15);
        JTextField textField2 = new JTextField(15);
        JTextField textField3 = new JTextField(15);
        JTextField textField4 = new JTextField(15);
        JTextField textField5 = new JTextField(15);
        JTextField textField6 = new JTextField(15);

        add(new JLabel("Enter Question :"));
        add(textField1);
        add(new JLabel("Option A"));
        add(textField2);
        add(new JLabel("Option B"));
        add(textField3);
        add(new JLabel("Option C"));
        add(textField4);
        add(new JLabel("Option D"));
        add(textField5);
        add(new JLabel("Correct Answer"));
        add(textField6);

        JButton submitButton = new JButton("Submit");
        add(submitButton);
        JButton backButton = new JButton("Back");
        add(backButton);

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String question = textField1.getText();
                String optionA = textField2.getText();
                String optionB = textField3.getText();
                String optionC = textField4.getText();
                String optionD = textField5.getText();
                String correctAnswer = textField6.getText();

                saveQuestionToDatabase(languageTable, question, optionA, optionB, optionC, optionD, correctAnswer);
                JOptionPane.showMessageDialog(null, "Added Successfully");
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new List().setVisible(true);
                setVisible(false);
            }
        });
    }

    private void saveQuestionToDatabase(String tableName, String question, String optionA, String optionB, String optionC, String optionD, String correctAnswer) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "root");
            String query = "INSERT INTO " + tableName + " (question, option1, option2, option3, option4, answer) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);

            pstmt.setString(1, question);
            pstmt.setString(2, optionA);
            pstmt.setString(3, optionB);
            pstmt.setString(4, optionC);
            pstmt.setString(5, optionD);
            pstmt.setString(6, correctAnswer);

            pstmt.executeUpdate();
            pstmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving to database. Please check your connection.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Text frame = new Text("JAVA");  // Example usage
            frame.setVisible(true);
        });
    }
}
