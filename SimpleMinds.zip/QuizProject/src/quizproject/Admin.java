package quizproject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Admin extends JFrame implements ActionListener {

    JButton button1, button2, button3,backImageButton;

    public Admin() {
        setTitle("Admin Dashboard");
        setSize(1440, 850);  // Set the same dimensions as your Quiz window
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocation(50, 0);  // Align with the main application window
        getContentPane().setBackground(Color.WHITE);  // Consistent background color
        
        
           // Back Image Button at Top Right Corner
        ImageIcon originalIcon = new ImageIcon(ClassLoader.getSystemResource("icon/back.png"));
        Image scaledImage = originalIcon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
        ImageIcon backIcon = new ImageIcon(scaledImage);

        backImageButton = new JButton(backIcon);
        backImageButton.setBounds(15, 15, 40, 40);  // Adjusted for top-right corner
        backImageButton.setBackground(Color.WHITE);
        backImageButton.setBorder(null);  // Remove border for icon button appearance
        backImageButton.addActionListener(this);
        add(backImageButton);


        // Header label for the dashboard
        JLabel headingLabel = new JLabel("Admin Dashboard");
        headingLabel.setFont(new Font("Tahoma", Font.BOLD, 40));
        headingLabel.setForeground(new Color(30, 144, 255));  // Same color as the buttons in Quiz
        headingLabel.setHorizontalAlignment(SwingConstants.CENTER);
        headingLabel.setBounds(0, 20, 1440, 60);

        // Load icons
        ImageIcon icon1 = new ImageIcon("icon/AQ.jpg");
        ImageIcon icon2 = new ImageIcon("icon/UP.jpg");
        ImageIcon icon3 = new ImageIcon("icon/UP.jpg");

        button1 = new JButton("Add Quiz", icon1);
        button2 = new JButton("Update Quiz", icon2);
        button3 = new JButton("Delete Quiz", icon3);

        // Style buttons to match the theme
        JButton[] buttons = {button1, button2, button3};
        for (JButton button : buttons) {
            button.setFont(new Font("Tahoma", Font.PLAIN, 24));
            button.setBackground(new Color(30, 144, 255));
            button.setForeground(Color.WHITE);
            button.setHorizontalTextPosition(SwingConstants.CENTER);
            button.setVerticalTextPosition(SwingConstants.BOTTOM);
            button.setPreferredSize(new Dimension(300, 300));
            button.addActionListener(this);
        }

        // Arrange buttons in a panel with consistent layout
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 50, 50));
        buttonPanel.setBounds(320, 150, 800, 600);
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.add(button1);
        buttonPanel.add(button2);
        buttonPanel.add(button3);

        // Add components to frame
        setLayout(null);
        add(headingLabel);
        add(buttonPanel);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == button1) {
            new List().setVisible(true);
            this.setVisible(false);
        } else if (ae.getSource() == button2) {
            new UP().setVisible(true);
            this.setVisible(false);
        } else if (ae.getSource() == button3) {
           new UP().setVisible(true);
            this.setVisible(false);
        }else if(ae.getSource()==backImageButton)
        {
            new AdminLogin();
        }
    }

    public static void main(String[] args) {
        new Admin();
    }
}
