package quizproject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class UpdateQuestionPage extends JFrame implements ActionListener {

    private JTextField questionField;
    private JButton saveButton, cancelButton;
    private JLabel titleLabel;
    private String tableName, originalQuestion;

    public UpdateQuestionPage(String tableName, String originalQuestion) {
        this.tableName = tableName;
        this.originalQuestion = originalQuestion;

        // Set window properties
        setTitle("Edit Question");
        setSize(600, 350);
        setLocationRelativeTo(null); // Center the window on the screen
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(20, 20));
        getContentPane().setBackground(new Color(255, 255, 255));

        // Title label
        titleLabel = new JLabel("Edit Question", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 30));
        titleLabel.setForeground(new Color(30, 144, 255));
        add(titleLabel, BorderLayout.NORTH);

        // Panel for the form fields
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setBackground(Color.WHITE);

        // Question input field
        questionField = new JTextField(originalQuestion, 20);
        questionField.setFont(new Font("Arial", Font.PLAIN, 18));
        questionField.setBackground(Color.LIGHT_GRAY);
        questionField.setForeground(Color.BLACK);
        questionField.setBorder(BorderFactory.createLineBorder(new Color(30, 144, 255), 2));
        questionField.setPreferredSize(new Dimension(500, 40));

        // Add the text field to the form panel
        formPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        formPanel.add(new JLabel("Question:"));
        formPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        formPanel.add(questionField);

        add(formPanel, BorderLayout.CENTER);

        // Button panel for Save and Cancel buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(Color.WHITE);

        saveButton = new JButton("Save Changes");
        saveButton.setFont(new Font("Arial", Font.BOLD, 18));
        saveButton.setBackground(new Color(30, 144, 255));
        saveButton.setForeground(Color.WHITE);
        saveButton.setPreferredSize(new Dimension(150, 40));
        saveButton.addActionListener(this);
        
        cancelButton = new JButton("Cancel");
        cancelButton.setFont(new Font("Arial", Font.BOLD, 18));
        cancelButton.setBackground(new Color(220, 53, 69));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setPreferredSize(new Dimension(150, 40));
        cancelButton.addActionListener(this);

        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);

        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == saveButton) {
            String updatedQuestion = questionField.getText().trim();

            if (updatedQuestion.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Question cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                updateQuestionInDatabase(updatedQuestion);
            }
        } else if (e.getSource() == cancelButton) {
            dispose(); // Close the window if cancel is clicked
        }
    }

    private void updateQuestionInDatabase(String updatedQuestion) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "root");
            PreparedStatement stmt = conn.prepareStatement(
                    "UPDATE " + tableName + " SET question = ? WHERE question = ?");

            stmt.setString(1, updatedQuestion);
            stmt.setString(2, originalQuestion);

            int rowsUpdated = stmt.executeUpdate();

            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(this, "Question updated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                dispose(); // Close the update page after successful update
            } else {
                JOptionPane.showMessageDialog(this, "Error updating question. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }

            stmt.close();
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating question in database.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new UpdateQuestionPage("Java", "What is Java?");  // Example usage with table "Java" and a sample question
    }
}
