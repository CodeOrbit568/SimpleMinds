package quizproject;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class Score extends JFrame implements ActionListener {

    JButton historyButton;
    String name;
    int score;

    Score(String name, int score) {
        this.name = name;
        this.score = score;
        
        
        setBounds(400, 150, 850, 550);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/score.png"));
        Image i2 = i1.getImage().getScaledInstance(300, 250, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 200, 300, 250);
        add(image);

        JLabel heading = new JLabel("Thank you " + name + " for playing Simple Minds");
        heading.setBounds(100, 30, 700, 30);
        heading.setFont(new Font("Tahoma", Font.PLAIN, 26));
        add(heading);

        JLabel lblscore = new JLabel("Your score is " + score);
        lblscore.setBounds(450, 200, 300, 30);
        lblscore.setFont(new Font("Tahoma", Font.PLAIN, 26));
        add(lblscore);

      

     
        historyButton = new JButton("History");
        historyButton.setBounds(480, 270, 120, 30);
        historyButton.setBackground(new Color(30, 144, 255));
        historyButton.setForeground(Color.WHITE);
        historyButton.addActionListener(this);
        add(historyButton);

       
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
      if(ae.getSource() == historyButton) {
            displayHistory();
        }
    }

    private void displayHistory() {
    try {
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "root");
        String query = "SELECT USERNAME, HIGH_SCORE FROM customer WHERE username = ?";
        PreparedStatement ps = con.prepareStatement(query);
        ps.setString(1, name);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            int highScore = rs.getInt("HIGH_SCORE"); 
// Use correct column name
            JOptionPane.showMessageDialog(this, "Username: " + name + "\nHigh Score: " + highScore, 
                                          "User History", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "No history found for user: " + name, 
                                          "User History", JOptionPane.INFORMATION_MESSAGE);
        }

        rs.close();
        ps.close();
        con.close();

    } catch (Exception e) {
        e.printStackTrace();
    }
}


    public static void main(String[] a) {
        new Score("user", 0);
    }
}
