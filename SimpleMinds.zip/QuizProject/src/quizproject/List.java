package quizproject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class List extends JFrame implements ActionListener {

    JButton backImageButton;

    public List() {
        // Set JFrame properties
        setTitle("Swing Form Example");
        setSize(800, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Set background color and layout
        getContentPane().setBackground(new Color(245, 245, 245));
        setLayout(new BorderLayout(10, 20));

        // Create and style heading label
        JLabel headingLabel = new JLabel("Select an Option", SwingConstants.CENTER);
        headingLabel.setFont(new Font("Verdana", Font.BOLD, 30));
        headingLabel.setForeground(new Color(0, 122, 204));
        headingLabel.setBorder(BorderFactory.createEmptyBorder(30, 0, 20, 0));
        add(headingLabel, BorderLayout.NORTH);

        ImageIcon originalIcon = new ImageIcon(ClassLoader.getSystemResource("icon/back.png"));
        Image scaledImage = originalIcon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
        ImageIcon backIcon = new ImageIcon(scaledImage);

        backImageButton = new JButton(backIcon);
        backImageButton.setBounds(10, 25, 40, 40);  // Adjusted for top-right corner
        backImageButton.setBackground(Color.WHITE);
        backImageButton.setBorder(null);  // Remove border for icon button appearance
        backImageButton.addActionListener(this);
        add(backImageButton);

        // Panel to hold combo box and button, with styling
        JPanel panel = new JPanel();
        panel.setBackground(new Color(245, 245, 245));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // ComboBox styling
        String[] options = {"JAVA", "OOP", "Mechanical", "Arts"};
        JComboBox<String> comboBox = new JComboBox<>(options);
        comboBox.setFont(new Font("SansSerif", Font.PLAIN, 18));
        comboBox.setPreferredSize(new Dimension(200, 40));
        comboBox.setMaximumSize(comboBox.getPreferredSize());
        comboBox.setAlignmentX(Component.CENTER_ALIGNMENT);
        comboBox.setBackground(Color.WHITE);
        comboBox.setForeground(Color.DARK_GRAY);
        panel.add(comboBox);

        // Add spacing between components
        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Submit button styling
        JButton submitButton = new JButton("Submit");
        submitButton.setFont(new Font("SansSerif", Font.BOLD, 18));
        submitButton.setBackground(new Color(0, 122, 204));
        submitButton.setForeground(Color.WHITE);
        submitButton.setFocusPainted(false);
        submitButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        submitButton.setPreferredSize(new Dimension(150, 50));
        panel.add(submitButton);

        // Adding the panel to the frame
        add(panel, BorderLayout.CENTER);

        // Action listener for the button
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedLanguage = (String) comboBox.getSelectedItem();
                new Text(selectedLanguage).setVisible(true);
                setVisible(false);
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            List frame = new List();
            frame.setVisible(true);
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == backImageButton) {
            this.dispose();
            new Admin().setVisible(true);
        }
    }
}
