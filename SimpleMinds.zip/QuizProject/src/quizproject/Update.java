package quizproject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Update extends JFrame implements ActionListener {

    private JList<String> questionList;
    private DefaultListModel<String> questionModel;
    private JButton updateButton, deleteButton, backImageButton;
    private String selectedTable;

    public Update(String selectedTable) {
        this.selectedTable = selectedTable;

        // Set the title and basic settings for the frame
        setTitle("Update Questions");
        setSize(1340, 700);  // Larger window for better space
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        
        // Back Image Button at Top Right Corner
        ImageIcon originalIcon = new ImageIcon(ClassLoader.getSystemResource("icon/back.png"));
        Image scaledImage = originalIcon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
        ImageIcon backIcon = new ImageIcon(scaledImage);

        backImageButton = new JButton(backIcon);
        backImageButton.setBounds(15, 15, 40, 40);  // Adjusted for top-right corner
        backImageButton.setBackground(Color.WHITE);
        backImageButton.setBorder(null);  // Remove border for icon button appearance
        backImageButton.addActionListener(this);
        add(backImageButton);

        // Panel for title and styling the top part of the UI
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(70, 130, 180));  // Steel blue background
        JLabel titleLabel = new JLabel("Update Question Here", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Sans Serif", Font.BOLD, 40));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);
        add(titlePanel, BorderLayout.NORTH);

        // Initialize the list model and JList to display questions
        questionModel = new DefaultListModel<>();
        questionList = new JList<>(questionModel);
        questionList.setFont(new Font("Arial", Font.PLAIN, 16));
        questionList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);  // Single selection mode
        JScrollPane scrollPane = new JScrollPane(questionList);
        scrollPane.setPreferredSize(new Dimension(800, 400));  // Set the preferred size for better fit
        add(scrollPane, BorderLayout.CENTER);

        // Update button with styling and icon
        updateButton = new JButton("Update Selected Question");
        updateButton.setFont(new Font("Arial", Font.PLAIN, 20));
        updateButton.setBackground(new Color(34, 193, 195));  // Teal color
        updateButton.setForeground(Color.WHITE);
        updateButton.setFocusPainted(false);  // Remove focus border
        updateButton.setBorder(BorderFactory.createLineBorder(new Color(28, 170, 163), 3));  // Border styling
        updateButton.addActionListener(this);

        // Delete button with styling
        deleteButton = new JButton("Delete Selected Question");
        deleteButton.setFont(new Font("Arial", Font.PLAIN, 20));
        deleteButton.setBackground(new Color(255, 69, 0));  // Red color
        deleteButton.setForeground(Color.WHITE);
        deleteButton.setFocusPainted(false);  // Remove focus border
        deleteButton.setBorder(BorderFactory.createLineBorder(new Color(220, 53, 69), 3));  // Border styling
        deleteButton.addActionListener(this);

        // Add buttons to the panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(new Color(240, 240, 240));  // Light gray background for the button panel
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        add(buttonPanel, BorderLayout.SOUTH);

        // Load questions from the database
        loadQuestionsFromDatabase();

        // Set the visible state of the frame
        setVisible(true);
    }

    private void loadQuestionsFromDatabase() {
        try {
            // Oracle JDBC connection setup
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "root");
            Statement stmt = conn.createStatement();

            // Query to load questions from the selected table
            String query = "SELECT question FROM \"" + selectedTable + "\"";
            ResultSet rs = stmt.executeQuery(query);

            // Populate the list with questions from the database
            while (rs.next()) {
                String question = rs.getString("question");
                questionModel.addElement(question);  // Add question to the list model
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading questions from database.");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Update.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == updateButton) {
            String selectedQuestion = questionList.getSelectedValue();
            if (selectedQuestion != null) {
                new UpdateQuestionPage(selectedTable, selectedQuestion); // Open update page
            } else {
                JOptionPane.showMessageDialog(this, "Please select a question to update.");
            }
        } else if (e.getSource() == deleteButton) {
            String selectedQuestion = questionList.getSelectedValue();
            if (selectedQuestion != null) {
                int confirmation = JOptionPane.showConfirmDialog(this, 
                        "Are you sure you want to delete this question?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
                if (confirmation == JOptionPane.YES_OPTION) {
                    deleteQuestionFromDatabase(selectedQuestion);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select a question to delete.");
            }
        } else if (e.getSource() == backImageButton) {
            // Dispose the current frame to free resources, if no longer needed
            this.dispose();
            new UP().setVisible(true);  // Assuming UP is a valid class for the back page
        }
    }

    private void deleteQuestionFromDatabase(String selectedQuestion) {
        try {
            // Oracle JDBC connection setup
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "root");
            Statement stmt = conn.createStatement();

            // SQL Query to delete the selected question from the table
            String deleteQuery = "DELETE FROM \"" + selectedTable + "\" WHERE question = ?";
            PreparedStatement preparedStatement = conn.prepareStatement(deleteQuery);
            preparedStatement.setString(1, selectedQuestion);
            int rowsAffected = preparedStatement.executeUpdate();

            // Show a message based on whether the deletion was successful
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Question deleted successfully.");
                questionModel.removeElement(selectedQuestion);  // Remove question from the UI list
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete the question.");
            }

            preparedStatement.close();
            stmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error deleting question from database.");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Update.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String[] args) {
        new Update("Java");  // Example usage with table name "Java"
    }
}
