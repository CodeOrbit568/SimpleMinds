package quizproject;

import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.sql.*;

public class AdminLogin extends JFrame implements ActionListener {
    JButton rules, backImageButton;
    JTextField fname;
    JPasswordField sname;

    AdminLogin() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/login.jpeg"));
        JLabel image = new JLabel(i1);
        image.setBounds(25, 20, 700, 630);
        add(image);
        
          JLabel heading = new JLabel("Simple Minds");
        heading.setBounds(555, 20, 300, 45);
        heading.setFont(new Font("Viner Hand ITC", Font.BOLD, 40));
        heading.setForeground(new Color(30, 144, 254));
        add(heading);

        ImageIcon originalIcon = new ImageIcon(ClassLoader.getSystemResource("icon/back.png"));
        Image scaledImage = originalIcon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
        ImageIcon backIcon = new ImageIcon(scaledImage);

        backImageButton = new JButton(backIcon);
        backImageButton.setBounds(10, 10, 40, 40);  // Adjusted for top-right corner
        backImageButton.setBackground(Color.WHITE);
        backImageButton.setBorder(null);  // Remove border for icon button appearance
        backImageButton.addActionListener(this);
        add(backImageButton);


        // Panel with border to contain the middle form components (username, password, and login button)
        JPanel contentPanel = new JPanel();
        contentPanel.setBounds(730, 90, 550, 500);
        contentPanel.setLayout(null);
        contentPanel.setBackground(Color.WHITE);
        contentPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(204, 204, 255), 5),
                "Login in Account", TitledBorder.CENTER, TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 20), new Color(30, 144, 254)
        ));
        add(contentPanel);


        
        JLabel name = new JLabel("Enter Your Username");
        name.setBounds(130, 110, 300, 20);
        name.setFont(new Font("Mangolian Baiti", Font.BOLD, 18));
        name.setForeground(new Color(30, 144, 254));
        contentPanel.add(name);

        fname = new JTextField();
        fname.setBounds(130, 145, 300, 25);
        fname.setFont(new Font("Times New Roman", Font.BOLD, 20));
        contentPanel.add(fname);

        JLabel pass = new JLabel("Enter Your Password");
        pass.setBounds(130, 220, 300, 20);
        pass.setFont(new Font("Mangolian Baiti", Font.BOLD, 18));
        pass.setForeground(new Color(30, 144, 254));
        contentPanel.add(pass);

        sname = new JPasswordField();
        sname.setBounds(130, 255, 300, 25);
        sname.setFont(new Font("Times New Roman", Font.BOLD, 20));
        contentPanel.add(sname);

        rules = new JButton("Login");
        rules.setBounds(170, 340, 150, 35);
        rules.setBackground(new Color(30, 144, 254));
        rules.setForeground(Color.WHITE);
        rules.addActionListener(this);
        contentPanel.add(rules);

        // Back Image Button at Top Right Corner
        
       setSize(1350, 740);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == rules) {
            System.out.println("Ok");

            // Trim the input to remove any extra whitespace
            String username = fname.getText().trim();
            String password = new String(sname.getPassword()).trim();

            System.out.println("Username entered: " + username);
            System.out.println("Password entered: " + password);

            try {
                Class.forName("oracle.jdbc.driver.OracleDriver");
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "root");

                String query = "SELECT * FROM admin WHERE LOWER(USERNAME) = LOWER(?) AND PASSWORD = ?";
                PreparedStatement ps = con.prepareStatement(query);
                ps.setString(1, username);
                ps.setString(2, password);

                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    JOptionPane.showMessageDialog(null, "Login Successful!");
                    setVisible(false);
                    new Admin();
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid Username or Password");
                }

                con.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        if (ae.getSource() == backImageButton) {
            setVisible(false);
            new AdminSignUp();
        }
    }

    public static void main(String[] a) {
        new AdminLogin();
    }
}
