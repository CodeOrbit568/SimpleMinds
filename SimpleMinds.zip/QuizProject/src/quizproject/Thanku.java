package quizproject;

import java.awt.*;
import javax.swing.*;

public class Thanku extends JFrame {
    
    Thanku()
    {
        setBounds(50, 0, 1440, 850);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/oip.jpg"));
        JLabel image = new JLabel(i1);
        image.setBounds(0, 0, 1440, 392);
        add(image);
        
        
    }
    
}
