package quizproject;

import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.sql.*;

public class Login extends JFrame implements ActionListener {

    JButton rules, backImageButton;
    JTextField fname;
    JPasswordField sname;

    Login() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        // Adding Image to Form
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/login.jpeg"));
        JLabel image = new JLabel(i1);
        image.setBounds(25, 0, 700, 630);
        add(image);

        // Back Image Button at Top Right Corner
        ImageIcon originalIcon = new ImageIcon(ClassLoader.getSystemResource("icon/back.png"));
        Image scaledImage = originalIcon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
        ImageIcon backIcon = new ImageIcon(scaledImage);

        backImageButton = new JButton(backIcon);
        backImageButton.setBounds(15, 15, 40, 40);  // Adjusted for top-right corner
        backImageButton.setBackground(Color.WHITE);
        backImageButton.setBorder(null);  // Remove border for icon button appearance
        backImageButton.addActionListener(this);
        add(backImageButton);

        // Heading
        JLabel heading = new JLabel("Simple Minds");
        heading.setBounds(630, 15, 300, 45);
        heading.setFont(new Font("Viner Hand ITC", Font.BOLD, 45));
        heading.setForeground(new Color(30, 144, 254));
        add(heading);

        JPanel contentPanel = new JPanel();
        contentPanel.setBounds(730, 90, 550, 470);
        contentPanel.setLayout(null);
        contentPanel.setBackground(Color.WHITE);
        contentPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(204, 204, 255), 5),
                "Login in Account", TitledBorder.CENTER, TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 20), new Color(30, 144, 254)
        ));
        add(contentPanel);

        // Username Label and Field
        JLabel name = new JLabel("Enter Your Username");
        name.setBounds(135, 90, 300, 20);
        name.setFont(new Font("Mangolian Baiti", Font.BOLD, 20));
        name.setForeground(new Color(30, 144, 254));
        contentPanel.add(name);

        fname = new JTextField();
        fname.setBounds(135, 120, 300, 25);
        fname.setFont(new Font("Times New Roman", Font.BOLD, 20));
        contentPanel.add(fname);

        // Password Label and Field
        JLabel pass = new JLabel("Enter Your Password");
        pass.setBounds(135, 170, 300, 20);
        pass.setFont(new Font("Mangolian Baiti", Font.BOLD, 20));
        pass.setForeground(new Color(30, 144, 254));
        contentPanel.add(pass);

        sname = new JPasswordField();
        sname.setBounds(135, 200, 300, 25);
        sname.setFont(new Font("Times New Roman", Font.BOLD, 20));
        contentPanel.add(sname);

        // Login Button
        rules = new JButton("Login");
        rules.setBounds(210, 260, 150, 35);
        rules.setBackground(new Color(30, 144, 254));
        rules.setForeground(Color.WHITE);
        rules.addActionListener(this);
        contentPanel.add(rules);

        setSize(1350, 640);
        setLocationRelativeTo(null);  // Center window on screen
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == rules) {
            System.out.println("Ok");

            String username = fname.getText().trim();
            String password = new String(sname.getPassword()).trim();

            try {
                Class.forName("oracle.jdbc.driver.OracleDriver");
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "root");

                String query = "SELECT * FROM customer WHERE LOWER(USERNAME) = LOWER(?) AND PASSWORD = ?";
                PreparedStatement ps = con.prepareStatement(query);
                ps.setString(1, username);
                ps.setString(2, password);

                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    JOptionPane.showMessageDialog(null, "Login Successful!");
                    setVisible(false);
                    new Rules(username);  // Pass the username to Rules page
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid Username");
                }

                con.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        if (ae.getSource() == backImageButton) {
            setVisible(false);
            new SignUp();
        }
    }

    public static void main(String[] a) {
        new Login();
    }
}
