
package quizproject;

import java.awt.*;
import javax.swing.*;
public class History extends JFrame {
    JTable jt;
    History(int i,String n,int i1,int i2,int i3,int i4){
        
        getContentPane().setBackground(Color.WHITE);
        setSize(1000,600);
        setVisible(true);
        
        jt=new JTable();
        
    }
    
    public static void main(String s[]){
        
    }
    
}
