package quizproject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.TitledBorder;

public class Rules extends JFrame implements ActionListener {

    String name;
    JButton Start, back;

    Rules(String name) {
        this.name = name;
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        JLabel heading = new JLabel("Welcome " + name + " to Simple Minds");
       heading.setBounds(350, 30, 700, 30);
        heading.setFont(new Font("Viner Hand ITC", Font.BOLD, 40));
        heading.setForeground(new Color(30, 144, 254));
        add(heading);
        
         JPanel contentPanel = new JPanel();
        contentPanel.setBounds(190, 90, 900, 600);
        contentPanel.setLayout(null);
        contentPanel.setBackground(Color.WHITE);
        contentPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(204, 204, 255), 5),
                " Read Carefully ", TitledBorder.CENTER, TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 20), new Color(30, 144, 254)
        ));
        add(contentPanel);

        JLabel rules = new JLabel();
        rules.setBounds(100, 90, 700, 350);
        rules.setFont(new Font("Tahoma", Font.PLAIN, 16));
        rules.setText(
            "<html>" + 
            "1. You are trained to be a programmer and not a storyteller, answer point to point.<br><br>" +
            "2. Do not unnecessarily smile at the person sitting next to you; they may also not know the answer.<br><br>" +
            "3. You may have a lot of options in life, but here all the questions are compulsory.<br><br>" +
            "4. Crying is allowed, but please do so quietly.<br><br>" +
            "5. Only a fool asks and a wise one answers (Be wise, not otherwise).<br><br>" +
            "6. Do not get nervous if your friend is answering more questions; maybe they are doing Jai Mata Di.<br><br>" +
            "7. Brace yourself, this paper is not for the faint-hearted.<br><br>" +
            "8. May you know more than what John Snow knows. Good Luck!<br><br>" +
            "</html>"
        );
        contentPanel.add(rules);

        back = new JButton("Back");
        back.setBounds(300, 500, 105, 40);
        back.setBackground(new Color(30, 144, 254));
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        contentPanel.add(back);

        Start = new JButton("Start");
        Start.setBounds(550, 500, 105, 40);
        Start.setBackground(new Color(30, 144, 254));
        Start.setForeground(Color.WHITE);
        Start.addActionListener(this);
        contentPanel.add(Start);

        setSize(1340, 750);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == Start) {
            setVisible(false);
            UserList userList = new UserList(name);
            userList.setVisible(true);  // Ensure UserList is made visible here
        } else {
            setVisible(false);
            new Login();
        }
    }

    public static void main(String[] args) {
        new Rules("User");
    }
}
