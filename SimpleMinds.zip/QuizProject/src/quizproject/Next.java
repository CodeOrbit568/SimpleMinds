package quizproject;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Next extends JFrame implements ActionListener 
{
    String name;
    ImageIcon im;
    JLabel l1,l2;
    JButton b1;
    Next(String name)
    {
        this.name = name;
        setBounds(50, 0, 1440, 850);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        
        JLabel heading=new JLabel("Simple Minds Next Level");
        heading.setBounds(590,60,300,45);
        heading.setFont(new Font("Viner Hand ITC",Font.BOLD,40));
        heading.setForeground(new Color(30,144,254));
        add(heading);
        
       ImageIcon i1 = new ImageIcon("D:/AGP Program/R.gif");
       JLabel image = new JLabel(i1);
       image.setBounds(0, 140, 1440, 392);
       add(image);
        
        b1 = new JButton("Proceed >>");
        b1.setBounds(690,590,100,25);
        b1.setBackground(new Color(30, 144, 255));
        b1.setForeground(Color.WHITE);
        b1.addActionListener(this);
        add(b1);
        
        setVisible(true);
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==b1)
        {
            setVisible(false);
     //       new Quiz1(name);
        }
        
    }
    
    public static void main(String s[]){
        new Next("user");
    }
    
    
    
    
}
