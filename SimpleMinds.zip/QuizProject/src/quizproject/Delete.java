package quizproject;
import javax.swing.*;
import java.awt.*;

public class Delete extends JFrame {

    public Delete() {
        setTitle("Centered Text");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800,650);
        // Create a label with centered text
        JLabel label = new JLabel("Delete Question Here !!");
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 50));
label.setForeground(Color.BLUE);
        // Add the label to the frame using BorderLayout.NORTH
        add(label, BorderLayout.NORTH);

        setVisible(true);
    }

    public static void main(String[] args) {
        new Delete();
    }
}