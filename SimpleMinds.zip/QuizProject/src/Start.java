package quizproject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;


public class Start extends JFrame implements ActionListener {

    JButton studentButton, adminButton;

    Start() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        
        // Heading Label
        JLabel heading = new JLabel("Simple Minds");
        heading.setBounds(510, 20, 400, 50);
        heading.setFont(new Font("Viner Hand ITC", Font.BOLD, 45));
        heading.setForeground(new Color(30, 144, 254));
        add(heading);
        
        
          // Panel with border to contain the middle form components (username, password, and login button)
        JPanel contentPanel = new JPanel();
        contentPanel.setBounds(190, 90, 900, 500);
        contentPanel.setLayout(null);
        contentPanel.setBackground(Color.WHITE);
        contentPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(204, 204, 255), 5),
                " Select Your Role ", TitledBorder.CENTER, TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 20), new Color(30, 144, 254)
        ));
        add(contentPanel);



        // Student Image Button
        // Student Image Button
        ImageIcon studentIcon = new ImageIcon(ClassLoader.getSystemResource("icon/stu.jpg"));
        Image studentImage = studentIcon.getImage().getScaledInstance(160, 185, Image.SCALE_SMOOTH); // Resize image to 100x100 pixels
        studentIcon = new ImageIcon(studentImage); // Recreate ImageIcon with resized image
        studentButton = new JButton("Student", studentIcon);
        studentButton.setBounds(160, 90, 230, 280);
        studentButton.setBackground(Color.WHITE);
        studentButton.setForeground(Color.BLACK);
        studentButton.setFont(new Font("Mangolian Baiti", Font.BOLD, 18));
        studentButton.setVerticalTextPosition(SwingConstants.BOTTOM);
        studentButton.setHorizontalTextPosition(SwingConstants.CENTER);
        studentButton.addActionListener(this);
        contentPanel.add(studentButton);

// Admin Image Button
        ImageIcon adminIcon = new ImageIcon(ClassLoader.getSystemResource("icon/Admin.jpeg"));
        Image adminImage = adminIcon.getImage().getScaledInstance(150, 183, Image.SCALE_SMOOTH); // Resize image to 100x100 pixels
        adminIcon = new ImageIcon(adminImage); // Recreate ImageIcon with resized image
        adminButton = new JButton("Admin", adminIcon);
        adminButton.setBounds(500, 90, 230, 280);
        adminButton.setBackground(new Color(30, 144, 254));
        adminButton.setForeground(Color.BLACK);
        adminButton.setFont(new Font("Mangolian Baiti", Font.BOLD, 18));
        adminButton.setVerticalTextPosition(SwingConstants.BOTTOM);
        adminButton.setHorizontalTextPosition(SwingConstants.CENTER);
        adminButton.addActionListener(this);
        contentPanel.add(adminButton);

        setSize(1350, 700);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == studentButton) {
            // Open the Student login page
            setVisible(false);
            new SignUp();  // assuming Login is the student login page
        } else if (ae.getSource() == adminButton) {
            // Open the Admin login page
            setVisible(false);
            new AdminSignUp();  // assuming Admin is the admin login page
        }
    }

    public static void main(String[] args) {
        new Start();
    }
}
